import os  
import subprocess  
import pandas
import glob
import argparse  

def parse_config_file(file_path):
    """
    解析配置文件，将其内容读入字典。
    假设每行都是 "键=值" 的形式，以 @ 开头的行表示一个区块的开始。
    """
    config = {}
    name_contents = {}
    current_name = None
    current_content = []
 
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()  # 去除行尾的换行符
            if not line or line.startswith('#'):  # 忽略空行和注释行
                continue
 
            if line.startswith('@'):
                # 处理区块开始行
                if current_name:
                    # 如果之前有区块名，保存当前区块内容
                    name_contents[current_name] = '\n'.join(current_content) + '\n'
                current_name = line[1:].strip()  # 去掉@并去除首尾空格
                current_content = []
            else:
                # 处理键值对或普通内容行
                if '=' in line:
                    # 如果是键值对，添加到config字典
                    key, value = line.split('=', 1)
                    config[key.strip()] = value.strip()
                else:
                    # 否则，添加到当前区块内容
                    current_content.append(line)
 
        # 处理最后一个区块（如果有的话）
        if current_name:
            name_contents[current_name] = '\n'.join(current_content) + '\n'
    config["sample_indicate_reps"]=name_contents["sample_indicate_reps"]
    config["sample_indicate_contrast"]=name_contents["sample_indicate_contrast"]
    return config

parser = argparse.ArgumentParser(description='读取配置文件并解析其内容。')  
parser.add_argument('config_file', type=str, help='配置文件的路径。')  
args = parser.parse_args()  
config = parse_config_file(args.config_file) 


GENOME_FA = config["GENOME_FA"]
GENOME_GFF=config["GENOME_GFF"]
GENOME_INDEX=config["GENOME_INDEX"]
# 注意：以下路径可能需要根据你的实际情况调整  
WORK_DIR = config["WORK_DIR"]
prepDE_path=config["prepDE_path"]
getTPM_path=config["getTPM_path"]
getFPKM_path=config["getFPKM_path"]
sample_indicate_reps=rf"{WORK_DIR}/sample_indicate_reps.txt"
sample_indicate_contrast=rf"{WORK_DIR}/sample_indicate_contrast.txt"
file_suffix_1=config["FILE_SUFFIX_1"]
file_suffix_2=config["FILE_SUFFIX_2"]

# 打开文件（如果文件不存在，它将被创建），使用'w'模式表示写入
with open(rf"{WORK_DIR}/sample_indicate_contrast.txt", 'w', encoding='utf-8') as file:
    # 将字符串写入文件
    file.write(config['sample_indicate_contrast'])
with open(rf"{WORK_DIR}/sample_indicate_reps.txt", 'w', encoding='utf-8') as file:
    # 将字符串写入文件
    file.write(config['sample_indicate_reps'])

SEQ_DATA_DIR = config["RNASEQ_DATA"]
FASTP_DIR = os.path.join(WORK_DIR, "fastp")  
HISAT_DIR = os.path.join(WORK_DIR, "hisat")  
STRINGTIE_DIR = os.path.join(WORK_DIR, "stringtie") 
DEG_DIR = os.path.join(WORK_DIR, "deg") 
WGCNA_DIR=os.path.join(WORK_DIR, "wgcna")
# 创建需要的目录  

os.makedirs(FASTP_DIR, exist_ok=True)  
os.makedirs(HISAT_DIR, exist_ok=True)  
os.makedirs(STRINGTIE_DIR, exist_ok=True)  
os.makedirs(DEG_DIR, exist_ok=True)  
#os.makedirs(WGCNA_DIR, exist_ok=True)  

if os.path.exists(os.path.join(FASTP_DIR,'command4fastp.list')):  
    result1 = subprocess.run(['rm', os.path.join(FASTP_DIR, 'command4fastp.list')], capture_output=True, text=True)
else:  
    pass
print("fastp start!")
commands = []
for filename in os.listdir(SEQ_DATA_DIR):
    if filename.endswith(file_suffix_1):##修改为你的fq文件后缀
        base_name = filename[:len(filename)-len(file_suffix_1)] ##修改为你的fq文件后缀
        r1_path = os.path.join(SEQ_DATA_DIR, filename)
        r2_path = os.path.join(SEQ_DATA_DIR, base_name + file_suffix_2)##修改为你的fq文件后缀
        output_prefix = os.path.join(FASTP_DIR, base_name)
        json_path = output_prefix + '.fastp.json'
        html_path = output_prefix + '.fastp.html'
        log_path = output_prefix + '.fastp.log'
        # 构建fastp命令
        print(base_name)
        cmd = f"fastp --thread 16 -i {r1_path} -I {r2_path} -o {output_prefix}.1.fq -O {output_prefix}.2.fq -j {json_path} -h {html_path} 2> {log_path}"
        commands.append(cmd)

# 将命令写入文件
with open(os.path.join(FASTP_DIR, 'command4fastp.list'), 'w') as f:
    for cmd in commands:
        f.write(cmd + '\n')

#运行fastp
#result1 = subprocess.run(['bash', os.path.join(FASTP_DIR, 'command4fastp.list')], capture_output=True, text=True)
if os.path.exists(os.path.join(HISAT_DIR,'command4hisat.list')):  
    result1 = subprocess.run(['rm', os.path.join(HISAT_DIR, 'command4hisat.list')], capture_output=True, text=True)
else:  
    pass

print("fastp finish!")
print("hisat2 start!")
# 遍历FASTP_DIR目录下的所有.1.fq文件并写入命令
with open(os.path.join(HISAT_DIR, 'command4hisat.list'), 'a') as file:  # 使用'a'模式来追加内容
    file.write(f"hisat2-build -p 16 {GENOME_FA} {GENOME_INDEX}\n")
    for filename in os.listdir(FASTP_DIR):
        if filename.endswith('.1.fq'):
            fq1 = os.path.join(FASTP_DIR, filename)
            fq2 = filename.replace('.1.fq', '.2.fq')
            fq2 = os.path.join(FASTP_DIR, fq2)
            base_name = filename[:-5]  # 去掉.1.fq扩展名
            print(filename)
            sam_file = os.path.join(HISAT_DIR, f"{base_name}.sam")
            log_file = os.path.join(HISAT_DIR, f"{base_name}.hisat2.log")
            summary_file = os.path.join(HISAT_DIR, f"{base_name}.hisat2.summary")

            hisat2_cmd = (
                f"hisat2 -x {GENOME_INDEX} -p 16 --dta -1 {fq1} -2 {fq2} -S {sam_file} --new-summary --summary-file {summary_file} 2> {log_file}"
            )

            samtools_cmd = (
                f"samtools sort -@ 8 -o {os.path.join(HISAT_DIR, f'{base_name}.bam')} {sam_file} 2> {os.path.join(HISAT_DIR, f'{base_name}.samtools.log')}"
            )

            # 写入命令到文件
            file.write(hisat2_cmd + "; " + samtools_cmd + "\n")
#运行hisat2
#result2 = subprocess.run(['bash', os.path.join(HISAT_DIR, 'command4hisat.list')], capture_output=True, text=True)
print("hisat2 finish!")
print("stringtie start!")
if os.path.exists(os.path.join(STRINGTIE_DIR,'command4stringtie.list')):  
    result1 = subprocess.run(['rm', os.path.join(STRINGTIE_DIR,'command4stringtie.list')], capture_output=True, text=True)
    result2 = subprocess.run(['rm','-rf', os.path.join(STRINGTIE_DIR,'edgeR.genes.dir')], capture_output=True, text=True)
else:  
    pass


#执行这一步要保证文件夹下的子文件夹只有几个样本的子文件夹，其他子文件夹存在则报错
with open(os.path.join(STRINGTIE_DIR,'command4stringtie.list'), 'w') as file:
    file.write(f"cd {STRINGTIE_DIR}"+ "\n")
    for filename in os.listdir(HISAT_DIR):
        if filename.endswith('.bam'):
            # 构造文件名变量
            base_name = filename.replace('.bam', '')
            base_name = os.path.splitext(os.path.basename(base_name))[0]

            # 构造hisat2命令
            stringtie_cmd = (
                f"stringtie -p 8 -G  {GENOME_GFF}  -e -B -o {base_name}/transcripts.gtf -A {base_name}/gene_abundances.tsv {HISAT_DIR}/{filename}"

            )
            # 写入命令到文件
            file.write(stringtie_cmd+"\n")
    file.write(f"python2 {prepDE_path}"+  "\n" + f"python2 {getTPM_path}"+"\n" + f"python2 {getFPKM_path}"+"\n")
    file.write(r"sed 's/,/\t/g' gene_count_matrix.csv > gene_count_matrix1.csv"+ "\n")
    file.write(f"run_DE_analysis.pl  --matrix gene_count_matrix1.csv --method edgeR --samples_file {sample_indicate_reps} --contrasts {sample_indicate_contrast} --output edgeR.genes.dir")##编写文件

    '''
sample_indicate_reps.txt文件中包含以下信息
WT	WT1
WT	WT2
WT	WT3
OE	OE1
OE	OE2
OE	OE3

sample_indicate_contrast.txt文件包含以下信息
OE	WT
'''
#运行stringtie
result3 = subprocess.run(['bash', os.path.join(STRINGTIE_DIR, 'command4stringtie.list')], capture_output=True, text=True)
print("stringtie finish!")


import pandas as pd

# 读取CSV文件Passionfruit-M_vs_Passionfruit-C修改为组名
folder_path = os.path.join(STRINGTIE_DIR, 'edgeR.genes.dir/')
# 使用glob模块匹配所有以DE_results结尾的文件  
de_results_files = glob.glob(folder_path + '*DE_results')
for i in de_results_files:
    DE_results = pd.read_csv(i,sep="\t")

    # 筛选FDR小于0.05且logFC大于1的行
    filtered_results = DE_results[(DE_results['FDR'] < 0.05) & ((DE_results['logFC'] > 1)|(DE_results['logFC'] < -1))]
    new_filename = f"{i}.filtered.csv"
    # 将筛选后的结果保存为新的CSV文件
    filtered_results.to_csv(new_filename, index=True)







